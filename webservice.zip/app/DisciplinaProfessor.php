<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DisciplinaProfessor extends Model
{
    //
}
