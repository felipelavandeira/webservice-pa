<?php

namespace App\Http\Controllers;

use App\Falta;

use Illuminate\Http\Request;

class FaltaController extends Controller
{

}
